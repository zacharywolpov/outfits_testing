module InputsHelper
end
