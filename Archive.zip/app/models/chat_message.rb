class ChatMessage < ApplicationRecord
end
